//Angular Core Imports
import { Injectable, HostBinding } from '@angular/core';

@Injectable()
export class TestService {
  backgroundColor: string = 'green';

  constructor() {}
}
