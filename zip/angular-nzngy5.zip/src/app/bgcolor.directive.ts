import {
  Directive,
  ElementRef,
  Renderer2,
  Component,
  Inject,
  Input,
  HostBinding
} from '@angular/core';
import { TestService } from './test.service';

@Directive({
  selector: '[bgcolor]',
})
export class BgColorDirective {
   @HostBinding('style.background-color') color: string = 'green';

  constructor(
    private testService: TestService,
    private element: ElementRef,
    private renderer: Renderer2,
  ) {}

  ngOnInit() {
  }
}
