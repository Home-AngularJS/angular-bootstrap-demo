import { Component } from '@angular/core';
import { TestService } from './test.service';
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  {
  bgColor: string;
  
  constructor(private testService:TestService){
    
  }

  ngOnInit(){
    this.bgColor = this.testService.backgroundColor;
  }
}
