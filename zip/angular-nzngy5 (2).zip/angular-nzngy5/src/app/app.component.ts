import { Component, OnInit } from '@angular/core';
import { TestService } from './test.service';
import { selectedReceiptNumber } from "./data.model";

const selected = {
  templateStyle: selectedReceiptNumber.templateStyle
}

@Component({
  selector: 'my-app',
  // template: '<div ' + selected.templateStyle + ' [innerHTML]="receiptNumber"></div>'

  // template: '<div [innerHTML]="receiptNumber" myClass1></div>'
  // template: '<strong><label><div [innerHTML]="receiptNumber"></div></label></strong>'
  // template: '<strong><div [innerHTML]="receiptNumber"></div></strong>'

  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit {
  receiptNumber: string;

  constructor(private testService: TestService) { }

  ngOnInit() {
    this.receiptNumber = selectedReceiptNumber.templateBody;
  }
}
