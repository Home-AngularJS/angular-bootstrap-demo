import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { TestService } from './test.service';
import { BgColorDirective } from './bgcolor.directive';
import {selectedReceiptNumber} from "./data.model";

@NgModule({
  imports: [
      BrowserModule,
      FormsModule
  ],
  declarations: [
      AppComponent,
      BgColorDirective
  ],
  providers: [TestService],
  bootstrap: [ AppComponent ]
})
export class AppModule {

  constructor() {
    selectedReceiptNumber.templateStyle = 'myClass1';
  }
}
