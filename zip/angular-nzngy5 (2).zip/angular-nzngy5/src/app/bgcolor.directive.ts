import { Directive, ElementRef, Renderer2, Component, Inject, Input, HostBinding, OnInit } from '@angular/core';
import { TestService } from './test.service';

@Directive({
  // selector: '[myClass1]',
  // selector: 'div [myClass1]',
  // selector: 'div',
  // selector: 'strong',
  // selector: 'strong div',
  // selector: 'strong label',
  selector: '<div>',

  // selector: '<label>',
})
export class BgColorDirective implements OnInit {
  @HostBinding('style.background-color') bgColor: string;
  @HostBinding('style.color') color: string;
  @HostBinding('style.padding') padding: string;

  constructor(private testService: TestService, private element: ElementRef, private renderer: Renderer2) { }

  ngOnInit() {
    this.bgColor = this.testService.bgColor;
    this.color = this.testService.color;
    this.padding = this.testService.padding;
  }
}
