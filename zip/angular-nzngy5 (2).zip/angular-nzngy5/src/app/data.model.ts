export const selectedReceiptNumber = {
    id: '',
    templateBody: '',
    templateName: '',
    templateStyle: ''
};
