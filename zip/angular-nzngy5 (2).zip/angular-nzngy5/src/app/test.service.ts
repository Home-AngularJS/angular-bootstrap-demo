import { Injectable, HostBinding } from '@angular/core';
import {selectedReceiptNumber} from "./data.model";

@Injectable()
export class TestService {
  bgColor: string;
  color: string;
  padding: string;

  constructor() {
    this.bgColor = '#6666ff';
    this.color = '#ffff00';
    this.padding = '10px';

    // selectedReceiptNumber.templateBody = '<label>The background color should be green</label>';
    selectedReceiptNumber.templateBody = '&lt;label&gt;The background color should be green&lt;/label&gt;';
    // selectedReceiptNumber.templateStyle = 'myClass1';
  }
}
