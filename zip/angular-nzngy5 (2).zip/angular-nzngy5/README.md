
* https://stackblitz.com/edit/angular-nzngy5
* https://medium.com/@ole.ersoy/adding-classes-dynamically-with-hostbinding-ac9a43f8a9b3
    https://stackblitz.com/edit/angular-hostbinding-class-demo
* [Установить класс Angular HostBinding css в значение с помощью функции?](https://issue.life/questions/49883601)
* [Angular & CSS Grid: Dynamic Grid Properties](https://itnext.io/angular-css-grid-dynamic-grid-properties-1a03634607a1)
* https://vike.io/ru/413382
* https://stackoverflow.com/questions/37965647/hostbinding-and-hostlistener-what-do-they-do-and-what-are-they-for
* [Взаимодействие с пользователем, HostListener и HostBinding](https://metanit.com/web/angular2/3.3.php)
* [Взаимодействие с пользователем, @HostListener и @HostBinding](https://xsltdev.ru/angular/guide/directives/user-interaction) 
* [Property/event binding with custom attribute directive in Angular](https://medium.com/@shachsan/property-event-binding-with-custom-attribute-directive-in-angular-d4dac5590774)

* https://medium.com/angular-in-depth/accessing-dom-elements-in-angular-directives-event-target-vs-elementref-9dd606b17840
* https://blog.exceptionfound.com/2019/05/06/css-grid-with-angular-directives
* https://stackblitz.com/edit/inner-html-host-binding

* [ngClass и ngStyle](https://metanit.com/web/angular2/3.1.php)
* http://stepansuvorov.com/blog/2017/01/angular2-possible-parameters-for-hostbinding-and-hostlistener-decorators/
* https://vike.io/ru/388180/
* `sanitizing unsafe URL value in Angular` http://roufid.com/warning-sanitizing-unsafe-url-value-angular/
* https://3-info.ru/post.php?post=3079
* https://src-bin.com/ru/q/20decb8

